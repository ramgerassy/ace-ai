export interface UserProfile {
  id: string;
  name: string;
  createdAt: number;
  lastLoginAt: number;
  quizHistory?: {
    quizId: string;
    subject: string;
    score: number;
    completedAt: number;
  }[];
}

export interface UserStorage {
  users: UserProfile[];
  currentUserId: string | null;
  lastActiveUserId: string | null;
}
