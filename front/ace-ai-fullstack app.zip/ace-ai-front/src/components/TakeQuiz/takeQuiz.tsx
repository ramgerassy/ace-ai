import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Button from '../Global/button';
import Card from '../Global/card';
import RadioGroup from '../Global/radioGroup';
import CheckboxGroup from '../Global/checkboxGroup';
import ProgressBar from '../Global/progressBar';
import Badge from '../Global/badge';
import { ApiClient } from '../../api/apiClient';
import { useQuiz, useUser } from '../../context/AppContext';
import type { 
  LegacyQuestion, 
  QuestionGenerationResponse, 
  UserAnswer as ApiUserAnswer 
} from '../../api/types';

interface QuizHeaderProps {
  currentQuestion: number;
  totalQuestions: number;
  progress: number;
  subject?: string;
  level?: string;
}

const QuizHeader = ({
  currentQuestion,
  totalQuestions,
  progress,
  subject = 'Quiz',
  level = 'intermediate',
}: QuizHeaderProps) => (
  <div className='mb-6'>
    <div className='flex justify-between items-center mb-4'>
      <Badge variant='secondary'>
        Question {currentQuestion + 1} of {totalQuestions}
      </Badge>
      <Badge>
        {subject} &bull; {level}
      </Badge>
    </div>
    <ProgressBar
      value={progress}
      showLabel
      label='Quiz Progress'
      className='mb-2'
    />
  </div>
);

interface QuizNavigationProps {
  currentQuestion: number;
  totalQuestions: number;
  hasAnswer: boolean;
  onPrevious: () => void;
  onNext: () => void;
  onBackToGenerate: () => void;
}

const QuizNavigation = ({
  currentQuestion,
  totalQuestions,
  hasAnswer,
  onPrevious,
  onNext,
  onBackToGenerate,
}: QuizNavigationProps) => (
  <div className='flex gap-3'>
    <Button
      variant='secondary'
      onClick={currentQuestion === 0 ? onBackToGenerate : onPrevious}
      className='flex-1'
    >
      {currentQuestion === 0 ? 'Back to Setup' : 'Previous'}
    </Button>
    <Button onClick={onNext} disabled={!hasAnswer} className='flex-1'>
      {currentQuestion === totalQuestions - 1 ? 'Finish Quiz' : 'Next Question'}
    </Button>
  </div>
);

// Convert legacy quiz data to API contract format for quiz review
const convertLegacyToApiFormat = (
  questions: LegacyQuestion[],
  answers: Record<string, string[]>
): ApiUserAnswer[] => {
  return questions.map((question, index) => {
    const userSelectedAnswers = answers[question.id] || [];
    // Convert option IDs ('a', 'b', 'c', 'd') to indices (0, 1, 2, 3)
    const userAnswerIndices = userSelectedAnswers.map(optionId => 
      optionId.charCodeAt(0) - 97 // 'a'=97, so 'a'->0, 'b'->1, etc.
    );
    
    // Convert correct answer IDs to indices
    const correctAnswerIndices = question.correctAnswers.map(optionId => 
      optionId.charCodeAt(0) - 97
    );

    return {
      questionNum: index + 1,
      question: question.question,
      possibleAnswers: question.options.map(opt => opt.text),
      correctAnswer: correctAnswerIndices,
      userAnswer: userAnswerIndices,
    };
  });
};

const TakeQuiz = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useUser();
  const { 
    session, 
    currentQuestion, 
    hasAnsweredCurrentQuestion, 
    progress,
    answerQuestion, 
    nextQuestion, 
    previousQuestion, 
    goToQuestion,
    setResults 
  } = useQuiz();

  useEffect(() => {
    // Redirect if not authenticated or no active quiz session
    if (!isAuthenticated) {
      navigate('/', { replace: true });
      return;
    }

    if (!session || !session.questions.length) {
      navigate('/generate-quiz', { replace: true });
      return;
    }
  }, [isAuthenticated, session, navigate]);

  const handleSingleAnswer = (value: string) => {
    if (!session || !currentQuestion) return;
    answerQuestion(currentQuestion.id, [value]);
  };

  const handleMultipleAnswers = (values: string[]) => {
    if (!session || !currentQuestion) return;
    answerQuestion(currentQuestion.id, values);
  };

  const handleNext = async () => {
    if (!session) return;

    const isQuizComplete = nextQuestion();
    
    if (isQuizComplete) {
      // Quiz completed, generate feedback
      const timeSpent = Math.floor((Date.now() - session.startTime) / 1000);

      try {
        // Convert to new API format
        const apiUserAnswers = convertLegacyToApiFormat(session.questions, session.answers);
        
        const reviewResponse = await ApiClient.reviewQuiz({
          userAnswers: apiUserAnswers,
        });

        if ('error' in reviewResponse) {
          console.error('Quiz review failed:', reviewResponse.error);
          // Fallback to basic results using context
          const basicScore = calculateBasicScore(session.questions, session.answers);
          setResults({
            basicScore,
            totalQuestions: session.questions.length,
          });
          navigate('/quiz-results');
          return;
        }

        if (reviewResponse.success) {
          // Set results in context
          setResults({
            // API response data
            score: reviewResponse.score,
            correctAnswers: reviewResponse.correctAnswers,
            totalQuestions: reviewResponse.totalQuestions,
            reflection: reviewResponse.reflection,
            questionReviews: reviewResponse.questionReviews,
          });
          navigate('/quiz-results');
        } else {
          console.error('Quiz review failed: Invalid response format');
          // Fallback to basic results
          const basicScore = calculateBasicScore(session.questions, session.answers);
          setResults({
            basicScore,
            totalQuestions: session.questions.length,
          });
          navigate('/quiz-results');
        }
      } catch (error) {
        console.error('Quiz review error:', error);
        // Fallback to basic results
        const basicScore = calculateBasicScore(session.questions, session.answers);
        setResults({
          basicScore,
          totalQuestions: session.questions.length,
        });
        navigate('/quiz-results');
      }
    }
  };

  const calculateBasicScore = (questions: LegacyQuestion[], answers: Record<string, string[]>) => {
    return questions.reduce((score, question) => {
      const userAnswer = answers[question.id] || [];
      const correctAnswers = question.correctAnswers || [];

      // Simple comparison for single-choice questions
      if (userAnswer.length === 1 && correctAnswers.length === 1) {
        return userAnswer[0] === correctAnswers[0] ? score + 1 : score;
      }

      // For multi-choice, check if arrays match
      const sortedUser = [...userAnswer].sort();
      const sortedCorrect = [...correctAnswers].sort();

      if (sortedUser.length === sortedCorrect.length) {
        const isCorrect = sortedUser.every(
          (answer, index) => answer === sortedCorrect[index]
        );
        return isCorrect ? score + 1 : score;
      }

      return score;
    }, 0);
  };

  const handlePrevious = () => {
    previousQuestion();
  };

  const handleBackToGenerate = () => {
    navigate('/generate-quiz');
  };

  // Show loading if no session
  if (!session || !session.questions.length) {
    return (
      <div className='min-h-[calc(100vh-4rem)] flex items-center justify-center'>
        <Card className='text-center space-y-4'>
          <div className='text-xl' style={{ color: 'var(--color-quiz-text)' }}>
            Loading quiz...
          </div>
          <div className='space-y-2'>
            <div className='w-64 h-2 bg-quiz-border rounded-full mx-auto'>
              <div className='h-2 bg-quiz-primary rounded-full animate-pulse w-1/2' />
            </div>
            <p
              className='text-sm opacity-70'
              style={{ color: 'var(--color-quiz-text)' }}
            >
              Preparing your personalized quiz
            </p>
          </div>
        </Card>
      </div>
    );
  }

  if (!currentQuestion) {
    return (
      <div className='min-h-[calc(100vh-4rem)] flex items-center justify-center'>
        <Card className='text-center space-y-4'>
          <div className='text-xl' style={{ color: 'var(--color-quiz-text)' }}>
            Question not found
          </div>
        </Card>
      </div>
    );
  }

  const currentAnswer = session.answers[currentQuestion.id] || [];

  // Detect if this is a multiple choice question (more than one correct answer)
  const isMultipleChoice = currentQuestion.correctAnswers.length > 1;

  // Convert Question format to options
  const answerOptions = currentQuestion.options.map(option => ({
    label: option.text,
    value: option.id,
  }));

  // Check if current question is properly answered
  const hasValidAnswer = isMultipleChoice 
    ? currentAnswer.length === currentQuestion.correctAnswers.length
    : currentAnswer.length > 0;

  return (
    <div className='min-h-[calc(100vh-4rem)] p-4'>
      <div className='max-w-4xl mx-auto py-8'>
        <QuizHeader
          currentQuestion={session.currentQuestionIndex}
          totalQuestions={session.questions.length}
          progress={progress}
          subject={session.metadata?.subject}
          level={session.metadata?.level}
        />

        <Card className='mb-6'>
          <div className='space-y-6'>
            <div className='space-y-2'>
              <div className='flex items-start justify-between'>
                <h2
                  className='text-xl font-semibold flex-1'
                  style={{ color: 'var(--color-quiz-text)' }}
                >
                  {currentQuestion.question}
                </h2>
                {currentQuestion.difficulty && (
                  <Badge
                    variant={
                      currentQuestion.difficulty === 'hard'
                        ? 'danger'
                        : currentQuestion.difficulty === 'medium'
                          ? 'warning'
                          : 'success'
                    }
                    size='sm'
                  >
                    {currentQuestion.difficulty}
                  </Badge>
                )}
              </div>

              {currentQuestion.subSubject && (
                <p
                  className='text-sm opacity-70'
                  style={{ color: 'var(--color-quiz-text)' }}
                >
                  Topic: {currentQuestion.subSubject}
                </p>
              )}
            </div>

            {/* Question Type Indicator */}
            <div className='mb-3'>
              <Badge 
                variant={isMultipleChoice ? 'warning' : 'secondary'} 
                size='sm'
              >
                {isMultipleChoice 
                  ? `Multiple Choice (Select ${currentQuestion.correctAnswers.length} answers)`
                  : 'Single Choice (Select 1 answer)'
                }
              </Badge>
            </div>

            {/* Answer Input */}
            {isMultipleChoice ? (
              <CheckboxGroup
                name={`question-${currentQuestion.id}`}
                options={answerOptions}
                values={currentAnswer}
                onChange={handleMultipleAnswers}
                label={`Select ${currentQuestion.correctAnswers.length} answers:`}
              />
            ) : (
              <RadioGroup
                name={`question-${currentQuestion.id}`}
                options={answerOptions}
                value={currentAnswer[0] || ''}
                onChange={handleSingleAnswer}
              />
            )}

            {/* Answer Progress for Multiple Choice */}
            {isMultipleChoice && (
              <div className='mt-3 p-3 bg-quiz-light rounded-lg'>
                <p className='text-sm' style={{ color: 'var(--color-quiz-text)' }}>
                  <strong>Progress:</strong> {currentAnswer.length} of {currentQuestion.correctAnswers.length} answers selected
                  {currentAnswer.length < currentQuestion.correctAnswers.length && (
                    <span className='text-amber-600 ml-2'>
                      (Select {currentQuestion.correctAnswers.length - currentAnswer.length} more)
                    </span>
                  )}
                  {currentAnswer.length === currentQuestion.correctAnswers.length && (
                    <span className='text-emerald-600 ml-2'>✓ Complete</span>
                  )}
                </p>
              </div>
            )}

            {currentQuestion.tags && currentQuestion.tags.length > 0 && (
              <div className='flex flex-wrap gap-1 pt-2'>
                {currentQuestion.tags.map((tag, index) => (
                  <Badge key={index} variant='secondary' size='sm'>
                    {tag}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </Card>

        <QuizNavigation
          currentQuestion={session.currentQuestionIndex}
          totalQuestions={session.questions.length}
          hasAnswer={hasValidAnswer}
          onPrevious={handlePrevious}
          onNext={handleNext}
          onBackToGenerate={handleBackToGenerate}
        />

        {/* Progress indicator */}
        <div className='mt-6 text-center'>
          <p
            className='text-sm opacity-70'
            style={{ color: 'var(--color-quiz-text)' }}
          >
            Time elapsed: {Math.floor((Date.now() - session.startTime) / 60000)}:
            {String(
              Math.floor(((Date.now() - session.startTime) % 60000) / 1000)
            ).padStart(2, '0')}
          </p>
        </div>
      </div>
    </div>
  );
};

export default TakeQuiz;
