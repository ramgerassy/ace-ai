import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { UserProfile } from '../types/user.types';
import {
  getCurrentUser as getStoredCurrentUser,
  getAllUsers as getStoredAllUsers,
  setCurrentUser as setStoredCurrentUser,
  createUser as createStoredUser,
  addUser as addStoredUser,
  deleteUser as deleteStoredUser,
  logoutCurrentUser as logoutStoredUser,
  userExistsWithName as checkUserExists,
} from '../utils/userStorage';
import { validateUserName } from '../utils/inputSanitization';

interface UserContextType {
  // State
  currentUser: UserProfile | null;
  allUsers: UserProfile[];
  isLoading: boolean;
  
  // Actions
  createUser: (name: string) => Promise<{ success: boolean; user?: UserProfile; error?: string }>;
  addUser: (name: string) => Promise<{ success: boolean; user?: UserProfile; error?: string }>;
  switchUser: (userId: string) => void;
  deleteUser: (userId: string) => void;
  logout: () => void;
  refreshUsers: () => void;
  
  // Helpers
  isAuthenticated: boolean;
  getUserById: (id: string) => UserProfile | undefined;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

interface UserProviderProps {
  children: ReactNode;
}

export const UserProvider = ({ children }: UserProviderProps) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load initial user data
  useEffect(() => {
    refreshUsers();
  }, []);

  const refreshUsers = () => {
    try {
      setIsLoading(true);
      const user = getStoredCurrentUser();
      const users = getStoredAllUsers();
      
      setCurrentUser(user);
      setAllUsers(users);
    } catch (error) {
      console.error('Failed to load user data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createUser = async (name: string): Promise<{ success: boolean; user?: UserProfile; error?: string }> => {
    // Validate the name
    const validation = validateUserName(name);
    if (!validation.isValid) {
      return { success: false, error: validation.error };
    }

    const trimmedName = name.trim();
    
    // Check if user already exists
    if (checkUserExists(trimmedName)) {
      return { success: false, error: 'A user with this name already exists' };
    }

    try {
      const newUser = createStoredUser(trimmedName);
      setCurrentUser(newUser);
      setAllUsers(getStoredAllUsers());
      
      return { success: true, user: newUser };
    } catch (error) {
      return { success: false, error: 'Failed to create user' };
    }
  };

  const addUser = async (name: string): Promise<{ success: boolean; user?: UserProfile; error?: string }> => {
    // Validate the name
    const validation = validateUserName(name);
    if (!validation.isValid) {
      return { success: false, error: validation.error };
    }

    const trimmedName = name.trim();
    
    // Check if user already exists
    if (checkUserExists(trimmedName)) {
      return { success: false, error: 'A user with this name already exists' };
    }

    try {
      const newUser = addStoredUser(trimmedName);
      // Don't change current user, just update the users list
      setAllUsers(getStoredAllUsers());
      
      return { success: true, user: newUser };
    } catch (error) {
      return { success: false, error: 'Failed to add user' };
    }
  };

  const switchUser = (userId: string) => {
    try {
      setStoredCurrentUser(userId);
      const user = getStoredCurrentUser();
      setCurrentUser(user);
    } catch (error) {
      console.error('Failed to switch user:', error);
    }
  };

  const deleteUser = (userId: string) => {
    try {
      deleteStoredUser(userId);
      const updatedUsers = getStoredAllUsers();
      setAllUsers(updatedUsers);
      
      // If deleted user was current user, clear current user
      if (currentUser?.id === userId) {
        setCurrentUser(null);
      }
    } catch (error) {
      console.error('Failed to delete user:', error);
    }
  };

  const logout = () => {
    try {
      logoutStoredUser();
      setCurrentUser(null);
    } catch (error) {
      console.error('Failed to logout:', error);
    }
  };

  const getUserById = (id: string): UserProfile | undefined => {
    return allUsers.find(user => user.id === id);
  };

  const value: UserContextType = {
    // State
    currentUser,
    allUsers,
    isLoading,
    
    // Actions
    createUser,
    addUser,
    switchUser,
    deleteUser,
    logout,
    refreshUsers,
    
    // Helpers
    isAuthenticated: !!currentUser,
    getUserById,
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};