import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { Question, QuestionGenerationResponse, QuestionFeedback, PerformanceAnalysis } from '../api/types';

interface ValidationState {
  subject: {
    validated: boolean;
    isValid: boolean;
    isAppropriate: boolean;
    suggestions: string[];
    warnings: string[];
    loading: boolean;
  };
  subSubjects: {
    validated: boolean;
    validSubjects: string[];
    invalidSubjects: string[];
    inappropriateSubjects: string[];
    suggestions: Record<string, string[]>;
    loading: boolean;
  };
}

interface QuizFormData {
  topic: string;
  subSubjects: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

interface QuizSession {
  questions: Question[];
  metadata: QuestionGenerationResponse['metadata'] | null;
  currentQuestionIndex: number;
  answers: Record<string, string[]>;
  startTime: number;
  isComplete: boolean;
}

interface QuizResults {
  // New API response fields
  score?: number;              // 0-100 percentage
  correctAnswers?: number;     // 0-10
  totalQuestions?: number;     // Always 10 for new API
  reflection?: string;         // 100-1000 chars personalized feedback
  questionReviews?: {
    questionNum: number;
    isCorrect: boolean;
    explanation?: string;     // Why answer was wrong/partial
  }[];
  
  // Legacy fields for backward compatibility
  feedback?: QuestionFeedback[];
  analysis?: PerformanceAnalysis;
  overallReview?: {
    grade: 'A+' | 'A' | 'B+' | 'B' | 'C+' | 'C' | 'D' | 'F';
    summary: string;
    strengths: string[];
    improvements: string[];
    nextSteps: string[];
  };
  basicScore?: number;
}

interface QuizContextType {
  // Quiz Generation State
  formData: QuizFormData;
  validationState: ValidationState;
  isGenerating: boolean;
  
  // Quiz Session State
  session: QuizSession | null;
  
  // Quiz Results State
  results: QuizResults | null;
  
  // Actions
  updateFormData: (data: Partial<QuizFormData>) => void;
  updateValidationState: (state: Partial<ValidationState>) => void;
  setGenerating: (loading: boolean) => void;
  
  startQuiz: (questions: Question[], metadata: QuestionGenerationResponse['metadata']) => void;
  answerQuestion: (questionId: string, answers: string[]) => void;
  goToQuestion: (index: number) => void;
  nextQuestion: () => boolean; // returns true if quiz is complete
  previousQuestion: () => void;
  
  setResults: (results: QuizResults) => void;
  resetQuiz: () => void;
  clearFormData: () => void;
  
  // Helpers
  canProceed: boolean;
  currentQuestion: Question | null;
  progress: number;
  hasAnsweredCurrentQuestion: boolean;
}

const QuizContext = createContext<QuizContextType | undefined>(undefined);

export const useQuiz = () => {
  const context = useContext(QuizContext);
  if (context === undefined) {
    throw new Error('useQuiz must be used within a QuizProvider');
  }
  return context;
};

interface QuizProviderProps {
  children: ReactNode;
}

const initialValidationState: ValidationState = {
  subject: {
    validated: false,
    isValid: false,
    isAppropriate: false,
    suggestions: [],
    warnings: [],
    loading: false,
  },
  subSubjects: {
    validated: false,
    validSubjects: [],
    invalidSubjects: [],
    inappropriateSubjects: [],
    suggestions: {},
    loading: false,
  },
};

const initialFormData: QuizFormData = {
  topic: '',
  subSubjects: '',
  difficulty: 'intermediate',
};

// localStorage keys
const QUIZ_FORM_DATA_KEY = 'ace-quiz-form-data';
const QUIZ_SESSION_KEY = 'ace-quiz-session';
const QUIZ_RESULTS_KEY = 'ace-quiz-results';
const QUIZ_VALIDATION_KEY = 'ace-quiz-validation';

// localStorage utilities
const saveToLocalStorage = (key: string, data: any) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    if (import.meta.env.DEV) {
      console.warn(`Failed to save ${key} to localStorage:`, error);
    }
  }
};

const loadFromLocalStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const stored = localStorage.getItem(key);
    if (stored) {
      return JSON.parse(stored) as T;
    }
  } catch (error) {
    if (import.meta.env.DEV) {
      console.warn(`Failed to load ${key} from localStorage:`, error);
    }
  }
  return defaultValue;
};

const clearFromLocalStorage = (key: string) => {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    if (import.meta.env.DEV) {
      console.warn(`Failed to clear ${key} from localStorage:`, error);
    }
  }
};

// Debug utility to check localStorage contents
const debugLocalStorage = () => {
  if (import.meta.env.DEV) {
    console.group('Quiz localStorage Debug');
    console.log('Form Data:', loadFromLocalStorage(QUIZ_FORM_DATA_KEY, null));
    console.log('Validation State:', loadFromLocalStorage(QUIZ_VALIDATION_KEY, null));
    console.log('Quiz Session:', loadFromLocalStorage(QUIZ_SESSION_KEY, null));
    console.log('Quiz Results:', loadFromLocalStorage(QUIZ_RESULTS_KEY, null));
    console.groupEnd();
  }
};

export const QuizProvider = ({ children }: QuizProviderProps) => {
  const [formData, setFormData] = useState<QuizFormData>(() => 
    loadFromLocalStorage(QUIZ_FORM_DATA_KEY, initialFormData)
  );
  const [validationState, setValidationState] = useState<ValidationState>(() =>
    loadFromLocalStorage(QUIZ_VALIDATION_KEY, initialValidationState)
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [session, setSession] = useState<QuizSession | null>(() =>
    loadFromLocalStorage(QUIZ_SESSION_KEY, null)
  );
  const [results, setResults] = useState<QuizResults | null>(() =>
    loadFromLocalStorage(QUIZ_RESULTS_KEY, null)
  );

  // Save to localStorage whenever state changes
  useEffect(() => {
    saveToLocalStorage(QUIZ_FORM_DATA_KEY, formData);
  }, [formData]);

  useEffect(() => {
    saveToLocalStorage(QUIZ_VALIDATION_KEY, validationState);
  }, [validationState]);

  useEffect(() => {
    if (session) {
      saveToLocalStorage(QUIZ_SESSION_KEY, session);
    } else {
      clearFromLocalStorage(QUIZ_SESSION_KEY);
    }
  }, [session]);

  useEffect(() => {
    if (results) {
      saveToLocalStorage(QUIZ_RESULTS_KEY, results);
    } else {
      clearFromLocalStorage(QUIZ_RESULTS_KEY);
    }
  }, [results]);

  // Debug utility in development
  useEffect(() => {
    if (import.meta.env.DEV) {
      // Make debug function available globally in development
      (window as any).debugQuizStorage = debugLocalStorage;
      
      // Auto-log localStorage contents when session changes
      if (session) {
        console.log('📚 Quiz session updated, localStorage contents:', {
          formData: loadFromLocalStorage(QUIZ_FORM_DATA_KEY, null),
          sessionQuestions: session.questions.length,
          currentIndex: session.currentQuestionIndex,
        });
      }
    }
  }, [session]);

  // Quiz Generation Actions
  const updateFormData = (data: Partial<QuizFormData>) => {
    setFormData(prev => ({ ...prev, ...data }));
  };

  const updateValidationState = (state: Partial<ValidationState>) => {
    setValidationState(prev => ({
      subject: { ...prev.subject, ...(state.subject || {}) },
      subSubjects: { ...prev.subSubjects, ...(state.subSubjects || {}) },
    }));
  };

  const setGenerating = (loading: boolean) => {
    setIsGenerating(loading);
  };

  // Quiz Session Actions
  const startQuiz = (questions: Question[], metadata: QuestionGenerationResponse['metadata']) => {
    setSession({
      questions,
      metadata,
      currentQuestionIndex: 0,
      answers: {},
      startTime: Date.now(),
      isComplete: false,
    });
    setResults(null); // Clear previous results
    clearFromLocalStorage(QUIZ_RESULTS_KEY); // Clear old results from localStorage
  };

  const answerQuestion = (questionId: string, answers: string[]) => {
    if (!session) return;
    
    setSession(prev => ({
      ...prev!,
      answers: {
        ...prev!.answers,
        [questionId]: answers,
      },
    }));
  };

  const goToQuestion = (index: number) => {
    if (!session || index < 0 || index >= session.questions.length) return;
    
    setSession(prev => ({
      ...prev!,
      currentQuestionIndex: index,
    }));
  };

  const nextQuestion = (): boolean => {
    if (!session) return false;
    
    if (session.currentQuestionIndex < session.questions.length - 1) {
      setSession(prev => ({
        ...prev!,
        currentQuestionIndex: prev!.currentQuestionIndex + 1,
      }));
      return false;
    } else {
      // Quiz complete
      setSession(prev => ({
        ...prev!,
        isComplete: true,
      }));
      return true;
    }
  };

  const previousQuestion = () => {
    if (!session || session.currentQuestionIndex <= 0) return;
    
    setSession(prev => ({
      ...prev!,
      currentQuestionIndex: prev!.currentQuestionIndex - 1,
    }));
  };

  const clearFormData = () => {
    setFormData(initialFormData);
    setValidationState(initialValidationState);
    
    // Clear form data from localStorage
    clearFromLocalStorage(QUIZ_FORM_DATA_KEY);
    clearFromLocalStorage(QUIZ_VALIDATION_KEY);
  };

  const resetQuiz = () => {
    setFormData(initialFormData);
    setValidationState(initialValidationState);
    setIsGenerating(false);
    setSession(null);
    setResults(null);
    
    // Clear localStorage
    clearFromLocalStorage(QUIZ_FORM_DATA_KEY);
    clearFromLocalStorage(QUIZ_VALIDATION_KEY);
    clearFromLocalStorage(QUIZ_SESSION_KEY);
    clearFromLocalStorage(QUIZ_RESULTS_KEY);
  };

  // Helper computed values
  const canProceed = formData.topic.trim() &&
    formData.subSubjects.trim() &&
    validationState.subject.validated &&
    validationState.subject.isValid &&
    validationState.subject.isAppropriate &&
    validationState.subSubjects.validated &&
    (validationState.subSubjects.validSubjects.length > 0 ||
      validationState.subSubjects.invalidSubjects.length > 0) &&
    validationState.subSubjects.inappropriateSubjects.length === 0;

  const currentQuestion = session ? session.questions[session.currentQuestionIndex] : null;
  
  const progress = session 
    ? ((session.currentQuestionIndex + 1) / session.questions.length) * 100 
    : 0;

  const hasAnsweredCurrentQuestion = session && currentQuestion
    ? !!session.answers[currentQuestion.id]?.length
    : false;

  const value: QuizContextType = {
    // State
    formData,
    validationState,
    isGenerating,
    session,
    results,
    
    // Actions
    updateFormData,
    updateValidationState,
    setGenerating,
    startQuiz,
    answerQuestion,
    goToQuestion,
    nextQuestion,
    previousQuestion,
    setResults,
    resetQuiz,
    clearFormData,
    
    // Helpers
    canProceed,
    currentQuestion,
    progress,
    hasAnsweredCurrentQuestion,
  };

  return (
    <QuizContext.Provider value={value}>
      {children}
    </QuizContext.Provider>
  );
};