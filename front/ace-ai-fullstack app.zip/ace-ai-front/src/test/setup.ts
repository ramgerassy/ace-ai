import '@testing-library/jest-dom';
import '../App.css';

// Mock CSS imports for tests
import.meta.env.VITEST = true;
